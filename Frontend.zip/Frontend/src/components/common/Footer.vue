<template>
    <div>
      <p class="copyright">Copyright © 2018 - <a href="http://www.istorms.net/">iStorms.</a> All Rights Reserved</p>
    </div>
</template>
<script>
export default{
}
</script>
<style lang='scss' scoped>
  .copyright {
    margin: 20px 0;
    font-size: 14px;
    color: #2d374b;
    a:hover {
      color: #36d1c4;
    }
  }
</style>
